import cv2
from ultralytics import YOLO

model = YOLO("yolov8n.pt")

video_path = r"E:\Python\video.mp4"
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print(f"❌ Could not open video file: {video_path}")
    exit()

while True:
    ret, frame = cap.read()
    if not ret:
        break

    results = model(frame[..., ::-1])
    annotated = results[0].plot()
    cv2.imshow("YOLOv8 Detection", annotated)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()